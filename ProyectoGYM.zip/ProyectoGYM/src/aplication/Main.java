package aplication;

import controllers.AuthControllers;

public class Main {

	public static void main(String[] args) {
		AuthControllers app = new AuthControllers();
		app.login();
	}

}
