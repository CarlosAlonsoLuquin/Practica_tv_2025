# PROYECTO GYM

<p>
Pasos para un buen funcionamiento
</p>

- Importar el estilo de fuente Anton-regular de dropbox

  [Dropbox](https://www.dropbox.com/scl/fo/3qtb5yt6mcqxikszzfubp/ADCrAzQwkpM9Yd1sJpyEpxM?rlkey=iyff08d40mgtq60pn01eef9nv&e=1&st=ug8160dx&dl=0)


-  Descargar el archivo ejecutable (PROYECTOGYM)

-  Puede ingresar con este usuario
  
   correo: jojo@gmail.com

   contraseña: 12345
 
- Usar preferentemente Java SE Development Kit 23
  
  [Java jdk 23](https://www.oracle.com/java/technologies/javase/jdk23-archive-downloads.html)


**Puedes registrarte!!**

